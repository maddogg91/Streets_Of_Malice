﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PlayerLibrary;
using OptionsLibrary;
using MobLibrary;
using ItemLibrary;


namespace Streets_Of_Malice
{/**

* October 8th, 2019

* CSC 253

* Jesse Watts 
* 
* Robert Charity

* Streets of Malice (Sprint #2)
* 
* Streets of Malice is an urban inspired dungeon crawler. Currently the build tests motion north, south, east, and west. Also allows user to see list of all available rooms and weapons.

*/
    class Program
    {

        static void Main(string[] args)
        {
            GameOptions.Startup();


           
        }
        




     

        

        


        //Contains methods for user inputs
        

        //Determines where the user moves when certain directions are added in
        
        

    }
}
